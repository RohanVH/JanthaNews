-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2022 at 05:06 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsjantha`
--

-- --------------------------------------------------------

--
-- Table structure for table `breakingnews`
--

CREATE TABLE `breakingnews` (
  `id` int(11) NOT NULL,
  `content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `breakingnews`
--

INSERT INTO `breakingnews` (`id`, `content`) VALUES
(1, 'ಅಕ್ರಮಗಳನ್ನು ಎಸಗಿರುವ ‘ಚಿಲುಮೆ’ ಸಂಸ್ಥೆಯ ಐವರನ್ನು ಪೊಲೀಸರು ಬಂಧಿಸಿ ವಿಚಾರಣೆ ಚುರುಕುಗೊಳಿಸಿದ್ದಾರೆ. ಚಿಲುಮೆಯ ಮುಖ್ಯಸ್ಥರಾದ ಕೆಂಪೇಗೌಡ, ರವಿಕುಮಾರ್, ನಿರ್ದೇಶಕ ರೇಣುಕಾ ಪ್ರಸಾದ್, ಮ್ಯಾನೇಜರ್ ಎಚ್.ಆರ್.ಧರ್ಮೇಶ್, ಮೇಲ್ವಿಚಾರಕರಾದ ಪ್ರಜ್ವಲ್ ಬಂಧಿತರು. ಹಲವು ಆಯಾಮದಲ್ಲಿ ಪ್ರಕರಣದ ತನಿಖೆ ಮುಂದುವರಿಸಿರುವ ಪೊಲೀಸರು ಇಂದಿನಿಂದ (ನ 21) ಬಿಬಿಎಂಪಿಯ ಕಂದಾಯ ಅಧಿಕಾರಿಗಳ ವಿಚಾರಣೆ ಚುರುಕುಗೊಳಿಸಿದ್ದಾರೆ.');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categories` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categories`) VALUES
('sports'),
('Business'),
('Health'),
('college'),
('Movies');

-- --------------------------------------------------------

--
-- Table structure for table `cat_content_details`
--

CREATE TABLE `cat_content_details` (
  `categories` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `datafile`
--

CREATE TABLE `datafile` (
  `id` int(11) NOT NULL,
  `categories` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `file_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datafile`
--

INSERT INTO `datafile` (`id`, `categories`, `subject`, `content`, `file_url`) VALUES
(1, 'Movies', 'Marks', 'Event\r\nDate:May 20th', 'video-63335110b12492.95412730.jpg'),
(2, 'Business', 's event', 'event\r\ndata: 20th may', 'video-633351a4696347.01184549.jpg'),
(3, 'Health', '#gdvibes', '25th jan  2k19', 'video-633352e647b8a1.06683289.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `id` int(11) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`id`, `email`, `password`) VALUES
(1, 'chrisrohan.cr4@gmail.com', 'rohan'),
(2, 'janathanewskannada@gmail.', 'janathanewskannada');

-- --------------------------------------------------------

--
-- Table structure for table `youtube`
--

CREATE TABLE `youtube` (
  `id` int(11) NOT NULL,
  `links` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `youtube`
--

INSERT INTO `youtube` (`id`, `links`) VALUES
(1, 'https://youtu.be/zup-BDHeUgE?list=UULFGvsGnqba6hHfEJYMaDQDkA'),
(2, 'https://youtu.be/aR-INceDJ4A?list=UULFGvsGnqba6hHfEJYMaDQDkA'),
(3, 'https://youtu.be/DaNEHg92KX4?list=UULFGvsGnqba6hHfEJYMaDQDkA'),
(4, 'https://youtu.be/DaNEHg92KX4?list=UULFGvsGnqba6hHfEJYMaDQDkA'),
(5, 'https://www.youtube.com/watch?v=LkbSM3ekEIQ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `breakingnews`
--
ALTER TABLE `breakingnews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datafile`
--
ALTER TABLE `datafile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `youtube`
--
ALTER TABLE `youtube`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `breakingnews`
--
ALTER TABLE `breakingnews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `datafile`
--
ALTER TABLE `datafile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signin`
--
ALTER TABLE `signin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `youtube`
--
ALTER TABLE `youtube`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
